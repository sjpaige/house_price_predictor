McCore Predict

## Description

This is a application that can predict the prices of houses, can display underlying data about the training data, and
it is also possible to save house price and house features for later viewing.


##Installation

To install the program make sure you have Python 3.7 and pip 20.x installed on the computer, then run the 
install.bat command file. Relies on pipenv to function and build the running enviroment.

The installer will run:
```cmd
py -V
pip install pipenv
pipenv install

```


##Debug
If the data needs to be reset you must use the data reset option in the debug menu of the application.
If you need to report an error then you can use the submit error report option.

##Contributing

The project is not open to contributions from others it is closed.


##License

Project uses opensource components but is not opensource itself. It is the intellectual property of McCore Investing LLC.